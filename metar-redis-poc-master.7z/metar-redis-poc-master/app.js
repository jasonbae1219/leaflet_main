var express = require("express");
const app = express();
require("dotenv").config();
var apiRouter = require("./routes/api");
var cors = require("cors");
const path = require("path");
const axios = require("axios");

const PORT = process.env.PORT || 8000;

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

//To allow cross-origin requests

app.use(cors());

//Routes
app.get("/metar-data/station", function (req, res) {
  let stationCode = req.query.scode;

  let url =
    "http://tgftp.nws.noaa.gov/data/observations/metar/stations/" +
    stationCode.toUpperCase() +
    ".TXT";

  axios
    .get(url)
    .then(function (result) {
      let data = result.data;
      res.status(result.status).send(data);
    })
    .catch(function (error) {
      res.status(500).send("Internal server error");
    });
});

app.get("/", function (req, res) {
  res.sendFile(path.join(__dirname, "/index.html"));
});

app.use(apiRouter);

// throw 404 if URL not found

app.all("*", function (req, res) {
  return res.status(404).json({
    error: true,
    code: 404,
    msg: "API Not Found",
  });
});

app.listen(PORT, () => {
  console.log(`Example app listening on port ${PORT}`);
});

module.exports = app;
