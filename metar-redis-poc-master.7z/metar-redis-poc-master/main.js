const weathSearchBox = document.getElementById("weathSearchBox");

weathSearchBox.addEventListener("input", searchWeatherData);

function searchWeatherData() {
  console.log(hey);
}
